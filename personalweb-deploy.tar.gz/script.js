document.addEventListener('DOMContentLoaded', function() {
    console.log('Script loaded and DOM is ready');
    
    // 轮播图相关代码 - 只在首页存在时执行
    const carousel = document.querySelector('.carousel');
    if (!carousel) return; // 如果不是首页，直接返回
    
    const slides = document.querySelectorAll('.slide');
    const prevButton = document.querySelector('.prev');
    const nextButton = document.querySelector('.next');
    const indicators = document.querySelectorAll('.indicator');
    
    if (slides.length === 0) return; // 如果没有轮播图元素，直接返回
    
    let currentSlide = 1;
    const slideCount = slides.length;

    // 初始化位置和样式
    updateCarousel(false);

    function updateCarousel(animate = true) {
        if (!carousel) return;
        
        if (!animate) {
            carousel.style.transition = 'none';
        } else {
            carousel.style.transition = 'transform 1s cubic-bezier(0.645, 0.045, 0.355, 1)';
        }
        
        carousel.style.transform = `translateX(-${currentSlide * 100}%)`;
        
        // 更新指示器状态
        const realIndex = (currentSlide - 1 + slideCount - 2) % (slideCount - 2);
        indicators.forEach((indicator, index) => {
            indicator.classList.toggle('active', index === realIndex);
        });

        // 更新幻灯片样式
        slides.forEach((slide, index) => {
            slide.classList.remove('active-slide', 'prev-slide', 'next-slide');
            if (index === currentSlide) {
                slide.classList.add('active-slide');
            } else if (index === currentSlide - 1) {
                slide.classList.add('prev-slide');
            } else if (index === currentSlide + 1) {
                slide.classList.add('next-slide');
            }
        });

        if (!animate) {
            // 强制重排
            carousel.offsetHeight;
        }
    }

    function nextSlide() {
        currentSlide++;
        updateCarousel(true);

        // 检查是否需要无缝切换
        if (currentSlide === slideCount - 1) {
            setTimeout(() => {
                currentSlide = 1;
                updateCarousel(false);
            }, 1000);
        }
    }

    function prevSlide() {
        currentSlide--;
        updateCarousel(true);

        // 检查是否需要无缝切换
        if (currentSlide === 0) {
            setTimeout(() => {
                currentSlide = slideCount - 2;
                updateCarousel(false);
            }, 1000);
        }
    }

    // 自动轮播
    let autoSlide = setInterval(nextSlide, 5000);

    // 添加按钮事件监听
    if (nextButton) {
        nextButton.addEventListener('click', () => {
            clearInterval(autoSlide);
            nextSlide();
            autoSlide = setInterval(nextSlide, 5000);
        });
    }

    if (prevButton) {
        prevButton.addEventListener('click', () => {
            clearInterval(autoSlide);
            prevSlide();
            autoSlide = setInterval(nextSlide, 5000);
        });
    }

    // 添加指示器点击事件
    indicators.forEach((indicator, index) => {
        indicator.addEventListener('click', () => {
            clearInterval(autoSlide);
            currentSlide = index + 1;
            updateCarousel(true);
            autoSlide = setInterval(nextSlide, 5000);
        });
    });

    // 添加过渡结束事件监听
    if (carousel) {
        carousel.addEventListener('transitionend', () => {
            if (currentSlide === 0) {
                currentSlide = slideCount - 2;
                updateCarousel(false);
            } else if (currentSlide === slideCount - 1) {
                currentSlide = 1;
                updateCarousel(false);
            }
        });
    }

    // 二维码弹窗相关代码 - 只在首页存在时执行
    const wechatModal = document.getElementById('wechat-modal');
    const douyinModal = document.getElementById('douyin-modal');
    const wechatIcon = document.getElementById('wechat-icon');
    const douyinIcon = document.getElementById('douyin-icon');
    const closeBtns = document.querySelectorAll('.close');

    if (wechatIcon && wechatModal) {
        // 点击微信图标显示弹窗
        wechatIcon.addEventListener('click', function(e) {
            e.preventDefault();
            wechatModal.style.display = "block";
        });
    }

    if (douyinIcon && douyinModal) {
        // 点击抖音图标显示弹窗
        douyinIcon.addEventListener('click', function(e) {
            e.preventDefault();
            douyinModal.style.display = "block";
        });
    }

    // 点击关闭按钮隐藏弹窗
    if (closeBtns.length > 0) {
        closeBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                if (wechatModal) wechatModal.style.display = "none";
                if (douyinModal) douyinModal.style.display = "none";
            });
        });
    }

    // 点击弹窗外部区域关闭弹窗
    window.addEventListener('click', function(event) {
        if ((event.target === wechatModal || event.target === douyinModal) && wechatModal && douyinModal) {
            wechatModal.style.display = "none";
            douyinModal.style.display = "none";
        }
    });

    // AI 对话相关代码 - 只在首页存在时执行
    const chatButton = document.getElementById('chat-button');
    const chatDialog = document.getElementById('chat-dialog');
    const closeChat = document.querySelector('.close-chat');
    const chatInput = document.getElementById('chat-input');
    const sendButton = document.getElementById('send-message');
    const chatMessages = document.querySelector('.chat-messages');

    // 如果AI对话元素不存在，直接返回
    if (!chatButton || !chatDialog || !chatInput || !sendButton || !chatMessages) {
        return; // 如果不是首页，直接返回
    }

    // 存储对话历史
    let conversationHistory = [{
        role: "system",
        content: "你一个AI助手，一个由再也不会开发的AI助手。你的回答应该专业、友好、准确。当涉及代码时，应该提供详细的解释和示例。请用中文回复。"
    }];

    // ���字机效果函数
    async function typeWriter(element, text) {
        const tokens = marked.lexer(text);
        let html = '';
        let currentIndex = 0;
        
        for (const token of tokens) {
            if (token.type === 'paragraph') {
                const words = token.text.split('');  // 修改为按字符分割
                for (const char of words) {
                    html += char;
                    element.innerHTML = marked.parse(html);
                    element.scrollIntoView({ behavior: 'smooth', block: 'end' });
                    await new Promise(resolve => setTimeout(resolve, 20));  // 减少延迟时间
                }
            } else if (token.type === 'code') {
                // 代码块一次性显示
                html += '```' + (token.lang || '') + '\n' + token.text + '\n```\n';
                element.innerHTML = marked.parse(html);
                element.scrollIntoView({ behavior: 'smooth', block: 'end' });
                await new Promise(resolve => setTimeout(resolve, 100));
                Prism.highlightAllUnder(element);  // 重新应用代码高亮
            } else {
                html += marked.parse(token.raw);
                element.innerHTML = html;
                element.scrollIntoView({ behavior: 'smooth', block: 'end' });
                await new Promise(resolve => setTimeout(resolve, 20));
            }
        }
    }

    // 发送消息到 360智脑 API
    async function sendToOpenAI(messages) {
        try {
            const response = await fetch('https://api.360.cn/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer fk2673363969.QHiisYhw8lOLBNeZamiSN7ilXfeNe6p-fb078d07'
                },
                body: JSON.stringify({
                    model: "360GPT_S2_V9",
                    messages: messages,
                    temperature: 0.7,
                    max_tokens: 2000,
                    stream: true
                })
            });

            if (!response.ok) {
                throw new Error('API 请求失败');
            }

            return response;
        } catch (error) {
            console.error('Error:', error);
            throw error;
        }
    }

    // 处理流式响应
    async function handleStream(response, messageContent) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        let markdown = '';

        try {
            while (true) {
                const { done, value } = await reader.read();
                if (done) break;

                buffer += decoder.decode(value);
                const lines = buffer.split('\n');
                buffer = lines.pop();

                for (const line of lines) {
                    if (line.trim() === '') continue;
                    if (line.startsWith('data: ')) {
                        const data = line.slice(6);
                        if (data === '[DONE]') continue;
                        try {
                            const json = JSON.parse(data);
                            const content = json.choices[0].delta.content;
                            if (content) {
                                markdown += content;
                                messageContent.innerHTML = marked.parse(markdown);
                                Prism.highlightAllUnder(messageContent);
                                messageContent.scrollIntoView({ behavior: 'smooth', block: 'end' });
                            }
                        } catch (e) {
                            console.error('Error parsing JSON:', e);
                        }
                    }
                }
            }
        } catch (error) {
            console.error('Error reading stream:', error);
            throw error;
        }

        return markdown;
    }

    // 发送消息
    async function sendMessage() {
        const message = chatInput.value.trim();
        if (message) {
            // 禁用输入和发送按钮
            chatInput.disabled = true;
            sendButton.disabled = true;
            sendButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

            // 添加用户消息
            const userMessage = document.createElement('div');
            userMessage.className = 'message user';
            userMessage.innerHTML = `
                <div class="message-content">
                    <p>${marked.parse(message)}</p>
                </div>
            `;
            chatMessages.appendChild(userMessage);

            // 更新对话历史
            conversationHistory.push({
                role: "user",
                content: message
            });

            // 清空输入框
            chatInput.value = '';
            chatInput.style.height = 'auto';

            // 滚动到底部
            chatMessages.scrollTop = chatMessages.scrollHeight;

            // 添加 AI 消息容器
            const aiMessage = document.createElement('div');
            aiMessage.className = 'message ai';
            aiMessage.innerHTML = `
                <div class="avatar">
                    <img src="images/image.png" alt="AI">
                </div>
                <div class="message-content">
                    <div class="typing-indicator">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            `;
            chatMessages.appendChild(aiMessage);
            chatMessages.scrollTop = chatMessages.scrollHeight;

            try {
                const response = await sendToOpenAI(conversationHistory);
                const messageContent = aiMessage.querySelector('.message-content');
                messageContent.innerHTML = '<div class="markdown-content"></div>';
                
                const aiResponse = await handleStream(response, messageContent.querySelector('.markdown-content'));
                
                // 更新对话历史
                conversationHistory.push({
                    role: "assistant",
                    content: aiResponse
                });

                // 如果对话历史太长，删除较早的消息
                if (conversationHistory.length > 10) {
                    conversationHistory = [
                        conversationHistory[0],
                        ...conversationHistory.slice(-4)
                    ];
                }

            } catch (error) {
                console.error('Error:', error);
                const messageContent = aiMessage.querySelector('.message-content');
                messageContent.innerHTML = '<p class="error">抱歉，我遇到了一些问题，请稍后再试。</p>';
            } finally {
                // 恢复输入和发送按钮
                chatInput.disabled = false;
                sendButton.disabled = false;
                sendButton.innerHTML = '<i class="fas fa-paper-plane"></i>';
                chatInput.focus();
            }
        }
    }

    // 打开对话框
    chatButton.addEventListener('click', () => {
        chatDialog.style.display = 'block';
        chatInput.focus();
    });

    // 关闭对话框
    closeChat.addEventListener('click', () => {
        chatDialog.style.display = 'none';
    });

    // 发送按钮点击事件
    sendButton.addEventListener('click', sendMessage);

    // 输入框回车发送
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    // 自动调整输入框高度
    chatInput.addEventListener('input', () => {
        chatInput.style.height = 'auto';
        chatInput.style.height = chatInput.scrollHeight + 'px';
    });


    // 3D Card Effect
    document.querySelector('.card-3d').addEventListener('mousemove', (e) => {
        const card = e.currentTarget;
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        
        const rotateX = (y - centerY) / 30;
        const rotateY = -(x - centerX) / 30;
        
        // 使用 requestAnimationFrame 优化动画性能
        requestAnimationFrame(() => {
            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        });
    });

    document.querySelector('.card-3d').addEventListener('mouseleave', (e) => {
        const card = e.currentTarget;
        requestAnimationFrame(() => {
            card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0)';
            card.style.transition = 'transform 0.8s cubic-bezier(0.23, 1, 0.32, 1)';
        });
    });

    document.querySelector('.card-3d').addEventListener('mouseenter', (e) => {
        const card = e.currentTarget;
        card.style.transition = 'transform 0.05s ease';
    });

    // Card Stack Effect
    const cardStack = document.querySelector('.card-stack');
    const cards = document.querySelectorAll('.card-stack-item');
    let currentIndex = 0;

    function rotateCards() {
        currentIndex = (currentIndex + 1) % cards.length;
        cards.forEach((card, index) => {
            const adjustedIndex = (index - currentIndex + cards.length) % cards.length;
            const offset = adjustedIndex * 40;
            const scale = 1 - (adjustedIndex * 0.05);
            card.style.transform = `translateY(${offset}px) scale(${scale})`;
            card.style.zIndex = (4 - adjustedIndex).toString();
            
            // 顶部卡片显示内容，其他卡片隐藏内容
            const content = card.querySelector('.card-stack-content');
            const title = content.querySelector('h3');
            const description = content.querySelector('p');
            
            if (adjustedIndex === 0) {
                // 顶部卡片，显示内容
                title.style.opacity = '1';
                title.style.transform = 'translateY(0)';
                description.style.opacity = '1';
                description.style.transform = 'translateY(0)';
            } else {
                // 其他卡片，隐藏内容
                title.style.opacity = '0';
                title.style.transform = 'translateY(20px)';
                description.style.opacity = '0';
                description.style.transform = 'translateY(20px)';
            }
        });
    }

    // 初始化卡片状态
    rotateCards();

    // 设置自动切换定时器
    let autoRotateInterval = setInterval(rotateCards, 3000);

    cards.forEach((card, index) => {
        card.addEventListener('mouseenter', () => {
            clearInterval(autoRotateInterval);  // 鼠标悬停时暂停自动切换
            
            // 当前卡片上移并放大，显示内容
            card.style.transform = 'translateY(-20px) scale(1.05)';
            card.style.zIndex = '5';
            
            const content = card.querySelector('.card-stack-content');
            const title = content.querySelector('h3');
            const description = content.querySelector('p');
            title.style.opacity = '1';
            title.style.transform = 'translateY(0)';
            description.style.opacity = '1';
            description.style.transform = 'translateY(0)';

            // 其他卡片向下移动并隐藏内容
            cards.forEach((otherCard, otherIndex) => {
                if (otherIndex !== index) {
                    const offset = otherIndex > index ? 
                        (otherIndex + 1) * 40 : 
                        otherIndex * 40;
                    const scale = 1 - (otherIndex * 0.05);
                    otherCard.style.transform = `translateY(${offset}px) scale(${scale})`;
                    otherCard.style.zIndex = otherIndex.toString();
                    
                    const otherContent = otherCard.querySelector('.card-stack-content');
                    const otherTitle = otherContent.querySelector('h3');
                    const otherDescription = otherContent.querySelector('p');
                    otherTitle.style.opacity = '0';
                    otherTitle.style.transform = 'translateY(20px)';
                    otherDescription.style.opacity = '0';
                    otherDescription.style.transform = 'translateY(20px)';
                }
            });
        });

        card.addEventListener('mouseleave', () => {
            // 恢复自动切换
            clearInterval(autoRotateInterval);  // 清除之前的定时器
            autoRotateInterval = setInterval(rotateCards, 3000);
            
            // 恢复所有卡片的原始位置和内容状态
            rotateCards();
        });
    });

    // 标记当前日期
    function markCurrentDate() {
        const now = new Date();
        const currentDate = now.getDate();
        const currentMonth = now.getMonth() + 1; // JavaScript 月份从 0 开始
        const currentYear = now.getFullYear();

        // 获取日历中显示的月份和年份
        const calendarMonth = document.querySelector('.calendar-header .month').textContent;
        const calendarYear = parseInt(document.querySelector('.calendar-header .year').textContent);

        // 将中文月份转换为数字
        const monthMap = {
            '一月': 1, '二月': 2, '三月': 3, '四月': 4,
            '五月': 5, '六月': 6, '七月': 7, '八月': 8,
            '九月': 9, '十月': 10, '十一月': 11, '十二月': 12
        };
        const displayedMonth = monthMap[calendarMonth];

        // 如果当前显示的是当前月份和年份，则标记当前日期
        if (displayedMonth === currentMonth && calendarYear === currentYear) {
            const dateElements = document.querySelectorAll('.calendar-date');
            dateElements.forEach(element => {
                if (element.textContent === currentDate.toString()) {
                    element.classList.add('current');
                }
            });
        }
    }

    // 页面加载时标记当前日期
    document.addEventListener('DOMContentLoaded', markCurrentDate);

    // 点击非对话框区域关闭对话框
    document.addEventListener('click', (event) => {
        const chatDialogContent = document.querySelector('.chat-dialog-content');
        if (chatDialog.style.display === 'block' && 
            !chatDialogContent.contains(event.target) && 
            !chatButton.contains(event.target)) {
            chatDialog.style.display = 'none';
        }
    });

    // 阻止对话框内部点击事件冒泡
    chatDialog.querySelector('.chat-dialog-content').addEventListener('click', (event) => {
        event.stopPropagation();
    });
});