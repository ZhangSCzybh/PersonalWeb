# 🌟 再也不会 - 个人技术品牌网站

一个融合技术与艺术美感的现代化个人网站，展现全栈开发实力与创意设计理念。集个人品牌展示、AI智能对话、工具资源整合于一体的综合性技术空间。

## 🎯 项目亮点

### ✨ 设计特色
- **3D交互体验**: 创新的卡片翻转和轨道动画效果
- **毛玻璃设计**: 现代化的毛玻璃视觉效果
- **响应式布局**: 完美适配桌面端和移动端
- **流畅动画**: CSS3和JavaScript驱动的丝滑过渡

### 🔧 技术架构
- **前端**: 纯HTML5 + CSS3 + JavaScript (无框架依赖)
- **动画**: CSS3 Transform + 自定义JavaScript动画
- **图标**: Font Awesome 6.0
- **字体**: Google Fonts (Inter系列)
- **代码高亮**: Prism.js
- **Markdown**: Marked.js解析

## 🚀 核心功能

### 🤖 AI智能助手
- 集成360智脑API
- 实时流式对话
- 代码高亮显示
- 智能上下文记忆

### 📱 服务展示
- **宝塔面板**: CA/JP节点管理
- **青龙面板**: 京东自动化/签到服务
- **Cloudreve**: 私有云存储
- **开发工具**: 一站式技术栈展示

### 🎨 视觉组件
- **3D卡片效果**: 鼠标悬停的立体交互
- **轨道动画**: 圆形轨道上的卫星运动
- **时间轴**: 优雅的个人历程展示
- **滚动字幕**: 自动循环的服务链接

## 🌐 在线体验

### 访问地址
- **主站**: [https://zaiyebuhui.eu.org](https://zaiyebuhui.eu.org)
- **GitHub**: [https://github.com/ZhangSCzybh/PersonalWeb](https://github.com/ZhangSCzybh/PersonalWeb)

### 页面导航
- 🏠 **首页** - 个人品牌展示 & 3D交互体验
- 💖 **收藏夹** - 技术资源整理 & 音乐分享
- 📊 **数据大盘** - 统计监控面板
- 📝 **记录列表** - 个人日志记录
- 📈 **统计分析** - 数据可视化展示
- 🚗 **车辆管理** - 特定功能管理页面

## 🛠️ 本地开发

### 快速开始
```bash
# 克隆项目
git clone https://github.com/ZhangSCzybh/PersonalWeb.git
cd PersonalWeb

# 启动本地服务器
python3 -m http.server 8000
# 或
npx http-server -p 8000
```

### 访问本地
打开浏览器访问: `http://localhost:8000`

### 开发环境
- **Python 3.x** (推荐) - 内置HTTP服务器
- **Node.js** - http-server或live-server
- **VSCode** - Live Server插件

## 📁 项目结构

```
PersonalWeb/
├── index.html          # 主页 - 个人介绍 & 3D展示
├── favorites.html      # 收藏夹 - 工具资源整理
├── dashboard.html      # 数据大盘 - 统计监控面板
├── records.html        # 记录列表 - 个人日志
├── analytics.html      # 统计分析 - 数据可视化
├── vehicles.html       # 车辆管理 - 特定功能页面
├── styles.css          # 全局样式文件
├── script.js           # 全局JavaScript功能
├── README.md           # 项目说明文档
├── images/             # 图片资源目录
│   ├── image.png       # 网站logo
│   ├── IMG_2041.JPG    # 微信二维码
│   ├── IMG_2042.JPG    # 抖音二维码
│   └── ...             # 其他品牌和应用图标
```

## 🎨 设计系统

### 色彩方案
- **主色调**: #2c3e50 (深蓝灰)
- **强调色**: #fa9104 (活力橙)
- **背景色**: #f5f5f5 (浅灰)
- **文字色**: #333333 (深灰)
- **辅助色**: #e74c3c (警告红) / #27ae60 (成功绿)

### 字体层级
- **主标题**: Inter ExtraBold 800 (36px)
- **副标题**: Inter Bold 700 (24px)
- **正文**: Inter Regular 400 (16px)
- **代码**: Monaco, Consolas (14px)
- **小字**: Inter Light 300 (14px)

### 间距系统
- 基于8px网格系统
- 响应式断点: 480px, 768px, 1024px, 1440px
- 容器最大宽度: 1200px (桌面端) / 100% (移动端)

### 动画系统
- **过渡时长**: 0.3s (标准) / 0.5s (慢速)
- **缓动函数**: ease-in-out (标准) / cubic-bezier (自定义)
- **3D变换**: translateZ, rotateY, perspective (800px)

## 🔧 自定义配置

### AI聊天配置
在 `script.js` 中修改API密钥：
```javascript
// 替换为你的360智脑API密钥
const API_KEY = 'your-api-key-here';
```

### 社交链接配置
在任意页面更新社交媒体链接：
```html
<!-- 修改为你的实际社交账号 -->
<a href="https://www.douyin.com/user/your-douyin-id" target="_blank">
  <i class="fab fa-tiktok"></i>
</a>
<a href="https://weixin.qq.com/your-wechat-qr" target="_blank">
  <i class="fab fa-weixin"></i>
</a>
```

### 服务链接更新
在 `index.html` 中更新服务地址：
```html
<!-- 修改为你的实际服务地址 -->
<a href="http://your-domain.com/login" target="_blank">服务名称</a>
```

### 个人信息
在 `index.html` 中更新个人信息：
```html
<!-- 修改为你的个人信息 -->
<h1>再也不会</h1>
<p>Full Stack Developer & Digital Creator</p>
```

### 二维码图片替换
将 `images/IMG_2041.JPG` 和 `images/IMG_2042.JPG` 替换为你的微信和抖音二维码图片，保持相同文件名即可自动更新。

## 📱 移动端优化

### 触摸交互
- 优化的触摸目标大小 (最小44x44px)
- 手势友好的滑动操作
- 减少hover依赖的交互设计

### 性能优化
- 图片懒加载
- CSS/JS文件压缩
- CDN资源加速
- 响应式图片适配

## 🚀 部署方案

### 静态托管 (推荐)
- **Vercel**: 一键部署，全球CDN，自动HTTPS
- **Netlify**: 持续集成部署，分支预览
- **GitHub Pages**: 免费静态托管，域名绑定
- **阿里云OSS**: 国内访问优化，OSS + CDN方案

### 本地服务器部署
```bash
# Python内置服务器 (推荐)
python3 -m http.server 9000

# Node.js http-server
npx http-server -p 9000 -o

# Live Server (VSCode插件)
# 右键任意HTML文件 → Open with Live Server
```

### Docker部署
```dockerfile
FROM nginx:alpine
COPY . /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

### Nginx配置示例
```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /var/www/personalweb;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # 静态资源缓存
    location ~* \.(css|js|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}

## 🤝 技术交流

### 联系方式
- **微信**: 扫描网站二维码添加
- **GitHub**: [ZhangSCzybh](https://github.com/ZhangSCzybh)
- **邮箱**: zhangshichao@example.com

### 贡献指南
1. Fork 项目
2. 创建特性分支
3. 提交Pull Request
4. 等待代码审查

## 🆕 更新日志

### v2.0.0 (当前版本)
- ✅ 新增数据大盘页面 (dashboard.html)
- ✅ 完善二维码弹窗功能 (微信/抖音)
- ✅ 优化移动端响应式体验
- ✅ 新增AI对话流式响应
- ✅ 统一全站设计风格

### v1.5.0
- ✅ 新增收藏夹页面 (favorites.html)
- ✅ 集成3D卡片组件
- ✅ 添加音乐播放器功能
- ✅ 优化导航栏交互

### v1.0.0
- ✅ 基础网站架构
- ✅ 主页3D展示效果
- ✅ AI智能对话集成
- ✅ 社交链接整合

## 📄 许可证

本项目采用 MIT 许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🙏 致谢

- **设计灵感**: Apple官网、Framer社区、Dribbble
- **技术资源**: MDN Web Docs、CSS-Tricks、Stack Overflow
- **图标来源**: Font Awesome 6.0、Heroicons
- **图片资源**: Unsplash、Pexels、GitHub
- **AI服务**: 360智脑API、OpenAI

## 🔮 未来规划

- [ ] 集成更多AI模型 (GPT-4o, Claude)
- [ ] 添加暗黑模式切换
- [ ] 实现PWA离线访问
- [ ] 集成用户登录系统
- [ ] 添加博客文章功能
- [ ] 集成音乐播放器API
- [ ] 实现数据可视化图表

---

<div align="center">
  <p><strong>⭐ 如果这个项目对你有帮助，请给个Star! ⭐</strong></p>
  <p>Made with ❤️ by <a href="https://github.com/ZhangSCzybh">再也不会</a></p>
  <p><em>持续更新中，敬请期待更多功能...</em></p>
</div>
